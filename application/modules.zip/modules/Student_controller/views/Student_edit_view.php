<div class="row">

    <div class="col-lg-12">
        <h1 class="page-header">Admin</h1>
    </div>
    
</div>

<div class="panel panel-default">

    <div class="panel-heading">
        Student Entry Form
    </div>

    <div class="panel-body">
        <div class="row">
            <div class="col-lg-6">

                <form role="form" method="POST" action= " <?php echo site_url('Student_controller/update_entry') ?>" >

                <?php if($student_data)
                { 
                    foreach($student_data as $row)
                    { 
                         //echo($row->addr); die; ?>

                        <input type= "hidden" name="sl_no" value= "<?php echo($row->sl_no);?>" required>
                    <!--    <input type= "hidden" name="date" value= "<?php //echo($row->created_dt);?>" required> -->
                        <input type= "hidden" name="date_m" value= "<?php echo date('y-m-d H:i:s');?>" required >
                        
                        <div class="form-group">
                            <label>Student Name</label>
                            <input class="form-control" name="stu_name" value= "<?php echo($row->stu_name); ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Roll No</label>
                            <input class="form-control" name="roll_no" value= "<?php echo($row->roll_no); ?>" required>
                        </div>

                        <div class="form-group">

                            <label>Class</label>
                            <select class="form-control" name="class_name" id="class_name" readonly>
                                
                                <option value= "<?php echo($row->class); ?>"><?php echo($row->class); ?></option>

                            </select>

                        </div>
                        
                        <div class="form-group">

                            <label>Section</label>
                            <select class="form-control" name="sec_name" id="sec_name" readonly>
                            
                                <option value= "<?php echo($row->sec); ?>"><?php echo($row->sec);  ?></option>

                            </select>

                        </div>
                        
                        <div class="form-group">
                            <label>Guardian's Name</label>
                            <input class="form-control" name="guardian" value= "<?php echo($row->guardian); ?>" placeholder="Guardian's Name" required>
                        </div>

                        <div class="form-group">
                            <label>Mobile No</label>
                            <input class="form-control" name="mob_no" value= "<?php echo($row->mob_no); ?>" required>
                        </div>
                         
                        <div class="form-group">
                            <label>Email Id</label>
                            <input class="form-control" name="mail_id" value= "<?php echo($row->mail_id); ?>" type="email" >
                        </div>

                                            
                        <div class="form-group">
                            <label>Address</label>
                            <textarea class="form-control" type= "text" name="addr"  rows="10" cols="50" placeholder="Address"><?php echo($row->addr); ?></textarea>
                        </div> 
                        
                        <button type="submit" class="btn btn-default">Submit</button>
                    
                    <?php } ?>

                <?php } ?>

                </form>
            </div>
        </div>
    </div>

</div>