<div class="row">

    <div class="col-lg-12">
        <h1 class="page-header">Admin</h1>
    </div>
    
</div>

<div class="panel panel-default">

    <div class="panel-heading">
        Student Entry Form
    </div>

    <div class="panel-body">
        <div class="row">
            <div class="col-lg-6">

                <form role="form" method="POST" action= " <?php echo site_url('Student_controller/index') ?>" >

                    <input type= "hidden" name="date_c" value= "<?php echo date('y-m-d H:i:s');?>" required >
                    
                    <div class="form-group">
                        <label>Student Name <font color="red">*</font></label>
                        <input class="form-control" name="stu_name" id="stu_name" placeholder="Student Name" required autofocus>
                    </div>
                    <div class="form-group">
                        <label>Roll No<font color="red">*</font></label>
                        <input class="form-control" name="roll_no" id="roll_no" placeholder="Roll No" required>
                    </div>

                    <div class="form-group">

                        <label>Class<font color="red">*</font></label>
                        <select class="form-control" name="class_name" required >
                            <option value= "">Select Class</option>

                        <?php    
                            foreach($class_data as $data)
                            {
                             ?>
                                <option value="<?php echo ($data->class_name); ?>"><?php echo ($data->class_name); ?></option>
                        <?php   
                            } 
                            ?>

                        </select>

                    </div>

                    <div class="form-group">
                        <label>Section<font color="red">*</font></label>
                        <select class="form-control" name="sec_name" required >
                            <option value= "">Select Section</option>
                            <option value= "A">A</option>
                            <option value= "B">B</option>
                            <option value= "C">C</option>
                            <option value= "D">D</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Guardian's Name<font color="red">*</font></label>
                        <input class="form-control" name="guardian" id="guardian" placeholder="Guardian's Name" required>
                    </div>

                    <div class="form-group">
                        <label>Mobile No.<font color="red">*</font></label>
                        <input class="form-control" name="mob_no" id="mob_no" pattern="[1-9]{1}[0-9]{9}" placeholder="Mobile No." required>
                    </div>
                    
                    <div class="form-group">
                        <label>Mail id</label>
                        <input class="form-control" type= "email" name="mail_id" id="mail_id" placeholder="Mail id" >
                    </div>

                    <div class="form-group">
                        <label>Address</label>
                        <textarea class="form-control" type= "text" name="addr" id="addr" rows="10" cols="50" placeholder="Address" ></textarea>
                    </div>   

                    <button type="submit" class="btn btn-default">Submit</button>

                </form>
            </div>
        </div>
    </div>

</div>