<?php

    defined('BASEPATH') OR exit('No direct script access allowed');
    
    class User_academy_model extends CI_Model
    {
   
        public function fetch_user()
        {

            $this->db->select('*');
            $this->db->where('user_type' == 'society');
            $data = $this->db->get('md_login_user');
            //var_dump($data); die;
            return $data->result(); 

        }

        public function new_user($user_name, $password, $user_type, $user_status, $created_by, $date_c)
        {

            $value = array('user_name' => $user_name,
                            'password'=> $password,
                            'user_type'=> $user_type,
                            'user_status'=> $user_status,
                            'created_by'=> $created_by,
                            'created_dt'=> $date_c);

            $this->db->insert('md_login_user',$value);

        }


        
    }

?>