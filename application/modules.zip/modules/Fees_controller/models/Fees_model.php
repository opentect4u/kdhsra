<?php

    defined('BASEPATH') OR exit('No direct script access allowed');

    class Fees_model extends CI_Model
    {

        public function fetch_table()
        {

            $this->db->select('*');
            $data = $this->db->get('md_fees');
			return $data->result(); 

        }


        public function new_fees($fees_name, $created_by, $date_c)
        {

            $value = array('fees_name' => $fees_name,
                        'created_by'=> $created_by,
                        'created_dt'=> $date_c);

            $this->db->insert('md_fees',$value);

        }


        public function f_edit_fees_data($sl_no)
        {
            $sql = $this->db->query("SELECT fees_name, sl_no FROM md_fees WHERE sl_no = $sl_no");
            return $sql->result();

        }


        public function update_fees($sl_no ,$fees_name, $modified_by, $date_m)
        {

            $value = array('fees_name' => $fees_name,
                        'modified_by'=> $modified_by,
                        'modified_dt'=> $date_m);         
                         
            $this->db->where('sl_no',$sl_no);
            $this->db->update('md_fees',$value);

        }

        

    }

?>