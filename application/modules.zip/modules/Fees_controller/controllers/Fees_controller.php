<?php

    if ( ! defined('BASEPATH'))  exit('No direct script access allowed');
    
    class Fees_controller extends MX_Controller
    {
        public function __construct()
        {
            parent::__construct();
            $this->load->model('Fees_model');
            
            $this->load->library('session'); //to get user_name from login_controller via session 

            if(!$this->session->userdata('loggedin'))
            {
                redirect('login_controller/login');
            }
            
        }

        public function main()
        {
            $this->load->view('post_login/academy/header');
            $this->fetch_table();
            $this->load->view('post_login/academy/footer');

        }

        public function fetch_table()
        {
            $fees_result['data'] = $this->Fees_model->fetch_table();

            //var_dump($class_result); die;

            $this->load->view('Fees_table', $fees_result);

        }


        public function entry()
        {

            $this->load->view('post_login/academy/header');
            $this->load->view('Fees_view');
            $this->load->view('post_login/academy/footer');

        }
       
       
        public function index()
        {

            if($this->session->userdata('loggedin'))
            {
                $created_by   =  $this->session->userdata('loggedin')->user_name; 
            }
            if($_SERVER['REQUEST_METHOD']=="POST")
            {
                $fees_name          =       $_POST['fees_name'];
                $date_c             =       $_POST['date_c'];

                $this->Fees_model->new_fees($fees_name, $created_by, $date_c);

                //echo $created_by; die;

                echo "<script> alert('Successfully Submitted');
                    document.location= 'main' </script>";
            
            }
            else
            {

                echo "<script> alert('Sorry! Password Missmatch');
                document.location= 'main' </script>";

            }

        }

        
        public function edit_entry($sl_no, $fees_name)
        {

            $this->load->view('post_login/academy/header');           
            
            //$fees_array['data']    =   array($sl_no, $fees_name);
            $fees_array['data'] = $this->Fees_model->f_edit_fees_data($sl_no);

            $this->load->view('Fees_edit_view', $fees_array);

            $this->load->view('post_login/academy/footer');

        }

        
        public function update_entry()
        {

            if($this->session->userdata('loggedin'))
            {
                $modified_by   =  $this->session->userdata('loggedin')->user_name; 
            }
            if($_SERVER['REQUEST_METHOD']=="POST")
            {

                $fees_name         =       $_POST['fees_name'];
                $sl_no              =       $_POST['sl_no'];
                $date_m             =       $_POST['date_m'];
                
                $this->Fees_model->update_fees($sl_no ,$fees_name, $modified_by, $date_m);

                echo "<script> alert('Successfully Updated');
                    document.location= 'main' </script>";

            }
            else
            {

                echo "<script> alert('Sorry!');
                document.location= 'main' </script>";

            }            

        }


    }

?>