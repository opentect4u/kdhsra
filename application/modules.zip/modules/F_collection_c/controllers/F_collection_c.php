<?php

    if ( ! defined('BASEPATH'))  exit('No direct script access allowed');
    
    class F_collection_c extends MX_Controller
    {
        public function __construct()
        {
            parent::__construct();
            $this->load->model('F_collection_m');
            
            $this->load->library('session'); //to get user_name from login_controller via session 

            if(!$this->session->userdata('loggedin'))
            {
                redirect('login_controller/login');
            }
            
        }

        public function main()
        {
            $this->load->view('post_login/academy/header');
            $this->fetch_table();
            $this->load->view('post_login/academy/footer');
        }

        public function fetch_table()
        {
            $today = date('y-m-d');
            $fees_result['data'] = $this->F_collection_m->fetch_table($today);
            //var_dump($class_result); die;
            $this->load->view('F_collection_table', $fees_result);
        }


        public function entry()
        {
			$result_details['class_data']  = $this->F_collection_m->f_get_class(); // to get the values of "td_class" table
			$result_details['fees_data']  = $this->F_collection_m->f_get_fees(); // to get the values of "td_fees" table
            
            //to create new transaction code for this date---
            $trans_dt       =       date('y-m-d'); 
            $result_details['trans_data'] = $this->F_collection_m->new_transCd($trans_dt);

            //var_dump($result_details['trans_data']); die;

            $this->load->view('post_login/academy/header');
            $this->load->view('F_collection_view', $result_details);
            $this->load->view('post_login/academy/footer');

        }

        public function get_student()
        {
            
            $class_name =   $this->input->get('class_name');
            $stu_sec    =   $this->input->get('stu_sec');
            $roll_no    =   $this->input->get('roll_no');
            //echo $class_name; die;

            $stu_result = $this->F_collection_m->get_student($class_name, $stu_sec, $roll_no);
            echo json_encode($stu_result);

        }

        public function index()
        {
            if($this->session->userdata('loggedin'))
            {
                $created_by   =  $this->session->userdata('loggedin')->user_name; 
            }

            $created_dt       =     date('y-m-d H:i:s');

            if($_SERVER['REQUEST_METHOD']=="POST")
            {
                
                $trans_dt       =       $_POST['trans_dt'];
                $trans_cd       =       $_POST['trans_cd'];
                $fees_month     =       $_POST['fees_month'];
                $fees_year      =       $_POST['fees_year'];
                $roll_no        =       $_POST['roll_no'];
                $stu_class      =       $_POST['stu_class'];
                $stu_sec        =       $_POST['stu_sec'];
                $stu_name       =       $_POST['stu_name'];
                $collc_mode     =       $_POST['collc_mode'];
                $bank_name      =       $_POST['bank_name'];
                $draft_no       =       $_POST['draft_no'];
                $neft_no        =       $_POST['neft_no'];
                $total          =       $_POST['total'];
                $remarks        =       $_POST['remarks'];
                $fees_type_id   =       $_POST['fees_type_id'];
                $fees_amount    =       $_POST['fees_amount'];


                $fees_count         =     count($fees_type_id);
                $fees_amount_count  =     count($fees_amount);

                //public function new_transCd($trans_dt);
                //echo $trans_dt; die;

                //echo $created_by; die;     

                $this->F_collection_m->new_fees($trans_dt, $trans_cd, $fees_month, $fees_year, $roll_no, $stu_class, $stu_sec, $stu_name,
                                                $collc_mode, $bank_name, $draft_no, $neft_no, $total, $remarks, $fees_type_id, 
                                                $fees_amount, $created_by, $created_dt);

                $this->F_collection_m->new_fees_details($trans_dt, $trans_cd, $fees_type_id, $fees_amount, $fees_count, $fees_amount_count, $created_by, $created_dt);

                echo "<script> alert('Successfully Submitted');
                document.location= 'main' </script>";

            }
            else
            {
                echo "<script> alert('Sorry! Try again');
                document.location= 'main' </script>";
            } 

        }


        public function edit_entry($trans_dt, $trans_cd)
        {

            //echo $trans_dt; echo $trans_cd; die;

            $this->load->view('post_login/academy/header');

            $edit_result['edit_data']  = $this->F_collection_m->f_get_edit_details($trans_dt, $trans_cd); 
            //echo "<pre>";
            //var_dump($edit_result['edit_data']); die;
			$edit_result['edit_fees_data']  = $this->F_collection_m->f_get_edit_fees_details($trans_dt, $trans_cd); 
            
            //$edit_result['edit_fees_payment'] = $this->F_collection_m->f_get_edit_fees_payment($trans_dt, $trans_cd);
            //echo "<pre>";
            //var_dump($edit_result['edit_fees_payment']); die;
           
            $edit_result['fees_type'] = $this->F_collection_m->f_get_fees();
            
            //echo "<pre>";
            //var_dump($edit_result['fees_type']); die;
            //$edit_result['edit_feesCount_data']  = $this->F_collection_m->f_get_edit_feesCount_details($trans_dt, $trans_cd); 

            $this->load->view('F_collection_edit', $edit_result);
            $this->load->view('post_login/academy/footer');

        }


        public function update_fees()
        {

            if($this->session->userdata('loggedin'))
            {
                $modified_by   =  $this->session->userdata('loggedin')->user_name; 
            }

            $modified_dt       =     date('y-m-d H:i:s');

            if($_SERVER['REQUEST_METHOD']=="POST")
            {

                $trans_dt       =       $_POST['trans_dt'];
                $trans_cd       =       $_POST['trans_cd'];
                $fees_month     =       $_POST['fees_month'];
                $fees_year      =       $_POST['fees_year'];
                $roll_no        =       $_POST['roll_no'];
                $stu_class      =       $_POST['stu_class'];
                $stu_sec        =       $_POST['stu_sec'];
                $stu_name       =       $_POST['stu_name'];
                $collc_mode     =       $_POST['collc_mode'];
                $bank_name      =       $_POST['bank_name'];
                $draft_no       =       $_POST['draft_no'];
                $neft_no        =       $_POST['neft_no'];
                $total          =       $_POST['total'];
                $remarks        =       $_POST['remarks'];
                $fees_type_id   =       $_POST['fees_type_id'];
                $fees_amount    =       $_POST['fees_amount'];

                $fees_count         =     count($fees_type_id);
                $fees_amount_count  =     count($fees_amount);

                $this->F_collection_m->Update_fees($trans_dt, $trans_cd, $fees_month, $fees_year, $roll_no, $stu_class, $stu_sec, $stu_name,
                                                $collc_mode, $bank_name, $draft_no, $neft_no, $total, $remarks, $fees_type_id, 
                                                $fees_amount, $modified_by, $modified_dt);

                $this->F_collection_m->update_fees_details($trans_dt, $trans_cd, $fees_type_id, $fees_amount, $fees_count, $fees_amount_count, $modified_by, $modified_dt);

                echo "<script> alert('Successfully Updated');
                document.location= 'main' </script>";

            }

            else
            {
                echo "<script> alert('Sorry! Try again');
                document.location= 'main' </script>";
            } 


        }


    }

?>