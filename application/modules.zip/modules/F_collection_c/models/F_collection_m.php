<?php

    defined('BASEPATH') OR exit('No direct script access allowed');

    class F_collection_m extends CI_Model
    {

        public function fetch_table($today)
        {
            $this->db->select('*');
            $this->db->where('trans_dt',$today);            
            $data = $this->db->get('td_fees_collection');
			return $data->result(); 
        }

        public function f_get_class()
        {
			$this->db->select('*');
			$data=$this->db->get('md_class');
            return $data->result(); 
        }

        public function get_student($class_name, $stu_sec, $roll_no)
        {
        
            $sql = $this->db->query("SELECT stu_name FROM md_student WHERE class = '$class_name'AND sec = '$stu_sec'AND roll_no = $roll_no ");
            return $sql->row();
        }

        public function f_get_fees()
        {
			$this->db->select('*');
			$data=$this->db->get('md_fees');
            return $data->result(); 
        }


        public function new_transCd($trans_dt)
        {
            //echo $trans_dt; die;

            $sql = $this->db->query("SELECT max(trans_cd) transCd FROM td_fees_collection WHERE trans_dt = '$trans_dt'");
            // "transCd" is a reference of "max(trans_cd)" to use it in view page 
            return $sql->row();
        }
        
        
        public function new_fees($trans_dt, $trans_cd, $fees_month, $fees_year, $roll_no, $stu_class, $stu_sec, $stu_name, $collc_mode, $bank_name, $draft_no, $neft_no, $total, $remarks, $fees_type_id, $fees_amount, $created_by, $created_dt)
        {

            $value = array('trans_dt' => $trans_dt,
                        'trans_cd' => $trans_cd,
                        'fees_month' => $fees_month,
                        'fees_year' => $fees_year,
                        'roll_no' => $roll_no,
                        'stu_class' => $stu_class,
                        'stu_sec' => $stu_sec,
                        'stu_name' => $stu_name,
                        'collc_mode' => $collc_mode,
                        'bank_name'=> $bank_name,
                        'draft_no'=> $draft_no,
                        'neft_no'=> $neft_no,
                        'total'=>$total,
                        'remarks'=>$remarks,
                        'created_by'=>$created_by,
                        'created_dt'=>$created_dt);

            $this->db->insert('td_fees_collection',$value);
     
        }


        public function new_fees_details($trans_dt, $trans_cd, $fees_type_id, $fees_amount, $fees_count, $fees_amount_count, $created_by, $created_dt)
        {

            for($i=0; $i<$fees_count; $i++)
            {
                $value = array('trans_dt' => $trans_dt,
                                'trans_cd' => $trans_cd,
                                'fees_type_id' => $fees_type_id[$i],
                                'fees_amount' => $fees_amount[$i],
                                'created_by' => $created_by,
                                'created_dt' => $created_dt);
            
                $this->db->insert('td_fees_collection_details',$value);

            }

        }


        public function f_get_edit_details($trans_dt, $trans_cd)
        {

            $result = $this->db->query(" SELECT * FROM td_fees_collection WHERE trans_dt= '$trans_dt' AND trans_cd= '$trans_cd' ");
 
            //echo "<pre>";
            //var_dump($result->result()); die;
            return $result->result();

        }

       /* public function f_get_edit_fees_payment($trans_dt, $trans_cd)
        {
            $result = $this->db->query("SELECT * FROM td_fees_collection_details WHERE trans_dt = '$trans_dt' AND trans_cd = '$trans_cd' ");
            return $result->result();

        } */
        
        
        public function f_get_edit_fees_details($trans_dt, $trans_cd)
        {

            $result = $this->db->query("SELECT * FROM td_fees_collection_details a, md_fees b WHERE trans_dt = '$trans_dt' AND trans_cd = '$trans_cd' AND a.fees_type_id = b.sl_no");
            return $result->result();

        }

        public function f_get_edit_feesCount_details($trans_dt, $trans_cd)
        {

            $result = $this->db->query("SELECT count(fees_amount) int_fees FROM td_fees_collection_details WHERE trans_dt = '$trans_dt' AND trans_cd = '$trans_cd' ");
            return $result->row();

        }


        public function Update_fees($trans_dt, $trans_cd, $fees_month, $fees_year, $roll_no, $stu_class, $stu_sec, $stu_name,
                                    $collc_mode, $bank_name, $draft_no, $neft_no, $total, $remarks, $fees_type_id, 
                                    $fees_amount, $modified_by, $modified_dt)
        {

            $value = array(
                        'fees_month' => $fees_month,
                        'fees_year' => $fees_year,
                        'roll_no' => $roll_no,
                        'stu_class' => $stu_class,
                        'stu_sec' => $stu_sec,
                        'stu_name' => $stu_name,
                        'collc_mode' => $collc_mode,
                        'bank_name'=> $bank_name,
                        'draft_no'=> $draft_no,
                        'neft_no'=> $neft_no,
                        'total'=>$total,
                        'remarks'=>$remarks,
                        'modified_by'=>$modified_by,
                        'modified_dt'=>$modified_dt);

            $this->db->where('trans_dt',$trans_dt);
            $this->db->where('trans_cd',$trans_cd);
            $this->db->update('td_fees_collection',$value);

        }


        public function update_fees_details($trans_dt, $trans_cd, $fees_type_id, $fees_amount, $fees_count,
                                            $fees_amount_count, $modified_by, $modified_dt)
        {

            for($i=0; $i<$fees_count; $i++)
            {
                $value = array(
                                'fees_type_id' => $fees_type_id[$i],
                                'fees_amount' => $fees_amount[$i],
                                'modified_by' => $modified_by,
                                'modified_dt' => $modified_dt);

                $this->db->where('trans_dt',$trans_dt);
                $this->db->where('trans_cd',$trans_cd);
                $this->db->where('fees_type_id',$fees_type_id[$i]);
                $this->db->update('td_fees_collection_details',$value);   

            }

        }




    }

?>